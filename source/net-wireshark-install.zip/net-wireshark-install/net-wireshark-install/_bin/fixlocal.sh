#!/bin/bash

# DUMMY

cd $HOME
# Do editcap to new file to avoid potential corruption
touch task.txt
echo -n 'export packet number: ' >> task.txt
echo -n PACKET_NUMBER >> task.txt
echo ' as txt' >> task.txt

cd /tmp
touch number.txt
echo -n 'number: ' >> number.txt
echo -n PACKET_NUMBER >> number.txt
echo ':' >> number.txt

